#!/usr/bin/env python
from colorama import Fore, Back, Style


def main():
    print(Fore.RED + 'Welcome to the Brain Games!')


if __name__ == '__main__':
    main()
